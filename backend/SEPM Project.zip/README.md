
  # SEPM Project

  This is a code bundle for SEPM Project. The original project is available at https://www.figma.com/design/H8d44Yu6RrsMzDqWfFEUWl/SEPM-Project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  