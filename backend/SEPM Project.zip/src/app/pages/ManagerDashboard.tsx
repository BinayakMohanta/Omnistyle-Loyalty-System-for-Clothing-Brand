import { ArrowLeft, TrendingUp, Users, Award, Crown, Gift, ShoppingBag } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Link } from "react-router";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";

export default function ManagerDashboard() {
  const kpiData = {
    totalPointsIssued: 2847500,
    activeGoldMembers: 1243,
    newSignups: 187
  };

  const redemptionTrends = [
    { date: "Feb 18", redemptions: 45, points: 12400 },
    { date: "Feb 21", redemptions: 52, points: 14200 },
    { date: "Feb 24", redemptions: 48, points: 13100 },
    { date: "Feb 27", redemptions: 61, points: 16800 },
    { date: "Mar 2", redemptions: 58, points: 15900 },
    { date: "Mar 5", redemptions: 67, points: 18500 },
    { date: "Mar 8", redemptions: 73, points: 20100 },
    { date: "Mar 11", redemptions: 69, points: 19200 },
    { date: "Mar 14", redemptions: 78, points: 21800 },
    { date: "Mar 17", redemptions: 82, points: 23400 },
    { date: "Mar 20", redemptions: 89, points: 25600 },
  ];

  const topShoppers = [
    { rank: 1, name: "Rajesh Kumar", tier: "Platinum", points: 12450, spend: 622500 },
    { rank: 2, name: "Priya Sharma", tier: "Platinum", points: 11280, spend: 564000 },
    { rank: 3, name: "Amit Patel", tier: "Gold", points: 9870, spend: 493500 },
    { rank: 4, name: "Sneha Reddy", tier: "Gold", points: 8920, spend: 446000 },
    { rank: 5, name: "Vikram Singh", tier: "Gold", points: 8450, spend: 422500 },
  ];

  const popularRewards = [
    { name: "₹500 Off Voucher", redemptions: 892, pointsUsed: 223000 },
    { name: "₹1000 Off Voucher", redemptions: 456, pointsUsed: 228000 },
    { name: "Free Accessory", redemptions: 1243, pointsUsed: 186450 },
    { name: "Premium Upgrade", redemptions: 187, pointsUsed: 187000 },
    { name: "Birthday Special", redemptions: 634, pointsUsed: 126800 },
  ];

  const tierDistribution = [
    { tier: "Platinum", count: 234, percentage: 5.2 },
    { tier: "Gold", count: 1243, percentage: 27.6 },
    { tier: "Silver", count: 2156, percentage: 47.9 },
    { tier: "Bronze", count: 871, percentage: 19.3 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-4">
          <Link to="/">
            <ArrowLeft className="w-6 h-6 text-gray-600 hover:text-gray-900" />
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl">Brand Manager Dashboard</h1>
            <p className="text-sm text-gray-600">Customer Retention & Analytics</p>
          </div>
          <Badge variant="outline" className="text-sm">
            Last updated: 20 Mar 2026, 14:32
          </Badge>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Total Points Issued
              </CardTitle>
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-semibold">
                {kpiData.totalPointsIssued.toLocaleString()}
              </div>
              <p className="text-sm text-green-600 mt-2">
                ↑ 12.5% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Active Gold Members
              </CardTitle>
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Crown className="w-5 h-5 text-yellow-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-semibold">
                {kpiData.activeGoldMembers.toLocaleString()}
              </div>
              <p className="text-sm text-green-600 mt-2">
                ↑ 8.3% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                New Signups (30d)
              </CardTitle>
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-semibold">
                {kpiData.newSignups}
              </div>
              <p className="text-sm text-green-600 mt-2">
                ↑ 15.7% from last month
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Redemption Trends Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Redemption Trends - Last 30 Days</CardTitle>
            <CardDescription>
              Daily redemption activity and points utilized
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={redemptionTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                />
                <YAxis 
                  yAxisId="left"
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                  label={{ value: 'Redemptions', angle: -90, position: 'insideLeft' }}
                />
                <YAxis 
                  yAxisId="right"
                  orientation="right"
                  tick={{ fontSize: 12 }}
                  stroke="#9ca3af"
                  label={{ value: 'Points', angle: 90, position: 'insideRight' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="redemptions" 
                  stroke="#8b5cf6" 
                  strokeWidth={3}
                  dot={{ fill: '#8b5cf6', r: 4 }}
                  name="Redemptions"
                />
                <Line 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="points" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', r: 4 }}
                  name="Points Used"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-6">
          {/* Top High-Value Shoppers */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-600" />
                Top High-Value Shoppers
              </CardTitle>
              <CardDescription>
                Customers with highest lifetime spend
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">Rank</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Tier</TableHead>
                    <TableHead className="text-right">Spend</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topShoppers.map((shopper) => (
                    <TableRow key={shopper.rank}>
                      <TableCell className="font-medium">
                        {shopper.rank}
                      </TableCell>
                      <TableCell>{shopper.name}</TableCell>
                      <TableCell>
                        <Badge 
                          variant={shopper.tier === "Platinum" ? "default" : "secondary"}
                          className={
                            shopper.tier === "Platinum" 
                              ? "bg-purple-600" 
                              : "bg-yellow-500"
                          }
                        >
                          {shopper.tier}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        ₹{shopper.spend.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Most Popular Rewards */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="w-5 h-5 text-blue-600" />
                Most Popular Rewards
              </CardTitle>
              <CardDescription>
                Highest redemption frequency
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Reward</TableHead>
                    <TableHead className="text-right">Redemptions</TableHead>
                    <TableHead className="text-right">Points Used</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {popularRewards.map((reward, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">
                        {reward.name}
                      </TableCell>
                      <TableCell className="text-right">
                        {reward.redemptions.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right">
                        {reward.pointsUsed.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Membership Tier Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-indigo-600" />
              Membership Tier Distribution
            </CardTitle>
            <CardDescription>
              Current member distribution across tiers
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              {tierDistribution.map((tier) => (
                <div 
                  key={tier.tier}
                  className="border rounded-lg p-4 text-center hover:shadow-md transition-shadow"
                >
                  <div className={`inline-flex w-12 h-12 rounded-full items-center justify-center mb-3 ${
                    tier.tier === "Platinum" ? "bg-purple-100" :
                    tier.tier === "Gold" ? "bg-yellow-100" :
                    tier.tier === "Silver" ? "bg-gray-100" :
                    "bg-orange-100"
                  }`}>
                    <Crown className={`w-6 h-6 ${
                      tier.tier === "Platinum" ? "text-purple-600" :
                      tier.tier === "Gold" ? "text-yellow-600" :
                      tier.tier === "Silver" ? "text-gray-600" :
                      "text-orange-600"
                    }`} />
                  </div>
                  <h3 className="font-semibold mb-1">{tier.tier}</h3>
                  <p className="text-2xl font-bold mb-1">{tier.count.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">{tier.percentage}% of total</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
