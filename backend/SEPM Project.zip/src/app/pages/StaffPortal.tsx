import { useState } from "react";
import { QrCode, Search, TrendingUp, User, Crown, ArrowLeft, Camera, CheckCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Link } from "react-router";
import { Label } from "../components/ui/label";

export default function StaffPortal() {
  const [activeSection, setActiveSection] = useState("scan");
  const [scannedCustomer, setScannedCustomer] = useState<any>(null);
  const [transactionAmount, setTransactionAmount] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const mockCustomers = {
    "RA2311003010004": {
      name: "Divyansh Manav",
      registrationNumber: "RA2311003010004",
      phone: "+91 98765 43210",
      points: 350,
      tier: "Gold Status",
      lifetimeSpend: 48500
    },
    "+919876543210": {
      name: "Divyansh Manav",
      registrationNumber: "RA2311003010004",
      phone: "+91 98765 43210",
      points: 350,
      tier: "Gold Status",
      lifetimeSpend: 48500
    }
  };

  const dailySales = [
    { time: "14:32", customer: "John Doe", amount: 3200, points: 64 },
    { time: "13:15", customer: "Sarah Smith", amount: 5100, points: 102 },
    { time: "12:45", customer: "Mike Johnson", amount: 2800, points: 56 },
    { time: "11:20", customer: "Emma Wilson", amount: 4500, points: 90 },
  ];

  const handleScan = () => {
    // Simulate QR code scan
    setTimeout(() => {
      setScannedCustomer(mockCustomers["RA2311003010004"]);
    }, 500);
  };

  const handleSearch = () => {
    const customer = mockCustomers[searchQuery as keyof typeof mockCustomers];
    if (customer) {
      setScannedCustomer(customer);
    }
  };

  const handleConfirmTransaction = () => {
    if (scannedCustomer && transactionAmount) {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        setShowSuccess(true);
        setTimeout(() => {
          setShowSuccess(false);
          setScannedCustomer(null);
          setTransactionAmount("");
        }, 2000);
      }, 1000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-4">
          <Link to="/">
            <ArrowLeft className="w-6 h-6 text-gray-600 hover:text-gray-900" />
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl">OmniStyle Staff Portal</h1>
            <p className="text-sm text-gray-600">Loyalty Transaction Management</p>
          </div>
          <Badge variant="outline" className="text-sm">
            Staff ID: ST-2024-001
          </Badge>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar */}
          <div className="col-span-3">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Navigation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <button
                  onClick={() => setActiveSection("scan")}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === "scan"
                      ? "bg-blue-50 text-blue-600"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <QrCode className="w-5 h-5" />
                  Scan QR
                </button>
                <button
                  onClick={() => setActiveSection("lookup")}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === "lookup"
                      ? "bg-blue-50 text-blue-600"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <Search className="w-5 h-5" />
                  Customer Lookup
                </button>
                <button
                  onClick={() => setActiveSection("sales")}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === "sales"
                      ? "bg-blue-50 text-blue-600"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  <TrendingUp className="w-5 h-5" />
                  Daily Sales
                </button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="col-span-9 space-y-6">
            {activeSection === "scan" && (
              <>
                {/* QR Scanner */}
                <Card>
                  <CardHeader>
                    <CardTitle>QR Code Scanner</CardTitle>
                    <CardDescription>
                      Position customer's QR code in the camera viewfinder
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center relative overflow-hidden">
                      {/* Simulated Camera View */}
                      <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-gray-900">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Camera className="w-24 h-24 text-gray-600" />
                        </div>
                        {/* Scanning Frame */}
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-64 h-64 border-4 border-blue-500 rounded-lg relative">
                            <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-white"></div>
                            <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-white"></div>
                            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-white"></div>
                            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-white"></div>
                          </div>
                        </div>
                      </div>
                      <p className="relative text-white text-center mt-80">
                        Camera viewfinder active
                      </p>
                    </div>
                    <div className="mt-4">
                      <Button onClick={handleScan} className="w-full" size="lg">
                        <QrCode className="w-5 h-5 mr-2" />
                        Simulate QR Scan
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Manual Search */}
                <Card>
                  <CardHeader>
                    <CardTitle>Manual Search</CardTitle>
                    <CardDescription>
                      Enter customer phone number if QR scan fails
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter phone number (e.g., +919876543210)"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      <Button onClick={handleSearch}>
                        <Search className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {activeSection === "lookup" && (
              <Card>
                <CardHeader>
                  <CardTitle>Customer Lookup</CardTitle>
                  <CardDescription>
                    Search for customers by phone number or registration ID
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Phone number or Registration ID"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      <Button onClick={handleSearch}>Search</Button>
                    </div>
                    <p className="text-sm text-gray-600">
                      Try: RA2311003010004 or +919876543210
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "sales" && (
              <Card>
                <CardHeader>
                  <CardTitle>Today's Sales</CardTitle>
                  <CardDescription>Recent loyalty transactions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {dailySales.map((sale, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <User className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium">{sale.customer}</p>
                            <p className="text-sm text-gray-600">{sale.time}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">₹{sale.amount.toLocaleString()}</p>
                          <p className="text-sm text-green-600">+{sale.points} points</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Customer Verification Card */}
            {scannedCustomer && (
              <Card className="border-2 border-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                    Customer Verified
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-600">Customer Name</Label>
                      <p className="text-lg font-semibold">{scannedCustomer.name}</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Registration Number</Label>
                      <p className="text-sm font-mono">{scannedCustomer.registrationNumber}</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Current Points</Label>
                      <p className="text-lg font-semibold">{scannedCustomer.points} pts</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Membership Tier</Label>
                      <Badge className="bg-yellow-500">
                        <Crown className="w-3 h-3 mr-1" />
                        {scannedCustomer.tier}
                      </Badge>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <Label htmlFor="amount">Transaction Amount (₹)</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Enter purchase amount"
                      value={transactionAmount}
                      onChange={(e) => setTransactionAmount(e.target.value)}
                      className="mt-2"
                    />
                    <p className="text-sm text-gray-600 mt-2">
                      Points to be awarded: {transactionAmount ? Math.floor(Number(transactionAmount) * 0.02) : 0}
                    </p>
                  </div>

                  <Button
                    onClick={handleConfirmTransaction}
                    className="w-full"
                    size="lg"
                    disabled={!transactionAmount || isProcessing}
                  >
                    {isProcessing ? "Processing..." : "Confirm & Add Points"}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Success Message */}
            {showSuccess && (
              <Card className="border-2 border-green-500 bg-green-50">
                <CardContent className="py-8">
                  <div className="text-center">
                    <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                    <h3 className="text-2xl font-semibold text-green-900 mb-2">
                      Transaction Successful!
                    </h3>
                    <p className="text-green-700">
                      Points have been added to customer account
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
