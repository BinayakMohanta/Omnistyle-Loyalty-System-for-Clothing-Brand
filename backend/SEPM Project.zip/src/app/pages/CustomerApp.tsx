import { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Home, Gift, History, Crown, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import { Badge } from "../components/ui/badge";
import { Link } from "react-router";

export default function CustomerApp() {
  const [activeTab, setActiveTab] = useState("home");
  
  const userData = {
    name: "Divyansh Manav",
    registrationNumber: "RA2311003010004",
    points: 350,
    maxPoints: 500,
    tier: "Gold Status"
  };

  const pointsPercentage = (userData.points / userData.maxPoints) * 100;

  const recentTransactions = [
    { id: 1, date: "2026-03-18", store: "OmniStyle Downtown", amount: 2500, points: 50 },
    { id: 2, date: "2026-03-15", store: "OmniStyle Mall", amount: 4200, points: 84 },
    { id: 3, date: "2026-03-10", store: "OmniStyle Express", amount: 1800, points: 36 },
    { id: 4, date: "2026-03-05", store: "OmniStyle Downtown", amount: 3100, points: 62 },
  ];

  const rewards = [
    { id: 1, name: "₹500 Off Voucher", points: 250, available: true },
    { id: 2, name: "₹1000 Off Voucher", points: 500, available: false },
    { id: 3, name: "Free Accessory", points: 150, available: true },
    { id: 4, name: "Premium Member Upgrade", points: 1000, available: false },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600 pb-20">
      {/* Header */}
      <div className="bg-white/10 backdrop-blur-sm px-4 py-3 flex items-center gap-3">
        <Link to="/">
          <ArrowLeft className="w-6 h-6 text-white" />
        </Link>
        <h1 className="text-xl text-white flex-1">OmniStyle Loyalty</h1>
      </div>

      {/* Main Content - Mobile Optimized */}
      <div className="max-w-md mx-auto px-4 py-6">
        {activeTab === "home" && (
          <div className="space-y-4">
            {/* Digital Loyalty Card */}
            <Card className="bg-gradient-to-br from-yellow-400 to-amber-500 text-white border-0 shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white text-2xl">OmniStyle</CardTitle>
                  <Badge className="bg-white/20 text-white border-white/30">
                    <Crown className="w-3 h-3 mr-1" />
                    {userData.tier}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-white/80 text-sm">Member Name</p>
                  <p className="text-xl">{userData.name}</p>
                </div>
                <div>
                  <p className="text-white/80 text-sm">Registration Number</p>
                  <p className="text-lg font-mono">{userData.registrationNumber}</p>
                </div>
              </CardContent>
            </Card>

            {/* Points Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Points Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-2xl">{userData.points} points</span>
                  <span className="text-gray-500">/ {userData.maxPoints}</span>
                </div>
                <Progress value={pointsPercentage} className="h-3" />
                <p className="text-sm text-gray-600">
                  {userData.maxPoints - userData.points} points until next reward
                </p>
              </CardContent>
            </Card>

            {/* QR Code */}
            <Card>
              <CardHeader>
                <CardTitle className="text-center">Your QR Code</CardTitle>
                <p className="text-sm text-gray-600 text-center">
                  Show this at checkout to earn points
                </p>
              </CardHeader>
              <CardContent className="flex justify-center py-6">
                <div className="bg-white p-4 rounded-lg shadow-inner">
                  <QRCodeSVG
                    value={userData.registrationNumber}
                    size={220}
                    level="H"
                    includeMargin={true}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "rewards" && (
          <div className="space-y-4">
            <h2 className="text-2xl text-white mb-4">Rewards Store</h2>
            {rewards.map((reward) => (
              <Card key={reward.id} className={!reward.available ? "opacity-60" : ""}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-semibold">{reward.name}</h3>
                      <p className="text-sm text-gray-600">{reward.points} points</p>
                    </div>
                    <Badge variant={reward.available ? "default" : "secondary"}>
                      {reward.available ? "Available" : "Locked"}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {activeTab === "history" && (
          <div className="space-y-4">
            <h2 className="text-2xl text-white mb-4">Purchase History</h2>
            {recentTransactions.map((transaction) => (
              <Card key={transaction.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">{transaction.store}</h3>
                      <p className="text-sm text-gray-600">{transaction.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">₹{transaction.amount.toLocaleString()}</p>
                      <p className="text-sm text-green-600">+{transaction.points} pts</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg">
        <div className="max-w-md mx-auto flex items-center justify-around py-3">
          <button
            onClick={() => setActiveTab("home")}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
              activeTab === "home" ? "text-purple-600 bg-purple-50" : "text-gray-600"
            }`}
          >
            <Home className="w-6 h-6" />
            <span className="text-xs">Home</span>
          </button>
          <button
            onClick={() => setActiveTab("rewards")}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
              activeTab === "rewards" ? "text-purple-600 bg-purple-50" : "text-gray-600"
            }`}
          >
            <Gift className="w-6 h-6" />
            <span className="text-xs">Rewards Store</span>
          </button>
          <button
            onClick={() => setActiveTab("history")}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
              activeTab === "history" ? "text-purple-600 bg-purple-50" : "text-gray-600"
            }`}
          >
            <History className="w-6 h-6" />
            <span className="text-xs">Purchase History</span>
          </button>
        </div>
      </div>
    </div>
  );
}
