import { Link } from "react-router";
import { Smartphone, Monitor, BarChart3 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-5xl mb-4 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            OmniStyle Loyalty System
          </h1>
          <p className="text-xl text-gray-600">
            Choose a view to explore the platform
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Smartphone className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>Customer Mobile App</CardTitle>
              <CardDescription>
                View your loyalty card, points, and QR code
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/customer">
                <Button className="w-full bg-purple-600 hover:bg-purple-700">
                  Open Customer View
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Monitor className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>Staff Web Portal</CardTitle>
              <CardDescription>
                Scan QR codes and process loyalty transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/staff">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Open Staff Portal
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-indigo-600" />
              </div>
              <CardTitle>Manager Dashboard</CardTitle>
              <CardDescription>
                Track metrics, analytics, and customer insights
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/manager">
                <Button className="w-full bg-indigo-600 hover:bg-indigo-700">
                  Open Manager Dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
